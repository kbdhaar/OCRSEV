CREATE DATABASE  IF NOT EXISTS `ocrsev` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ocrsev`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ocrsev
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'ocrsev'
--
/*!50003 DROP PROCEDURE IF EXISTS `brfss_role2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `brfss_role2`()
BEGIN
DECLARE n INT DEFAULT 0;
DECLARE i INT DEFAULT 0;
DECLARE m INT DEFAULT 0;

SET m = 6923;

SELECT 
    COUNT(*)
FROM
    brfss_smart INTO n;  # setting n = number of records in tmp_humref1 = 97
    
SET i = 0; 

#Step 1
WHILE i<n DO

update brfss_smart
set role2_uri = concat('SEV_000000', m)
where rown = (i + 1);

SET i = i + 1;
SET m = m + 1;

END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `demo_zip` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `demo_zip`()
BEGIN
DECLARE n INT DEFAULT 0;
DECLARE i INT DEFAULT 0;
DECLARE m INT DEFAULT 0;
DECLARE zip INT DEFAULT 0;

SELECT 
    COUNT(*)
FROM
    demo INTO n;  # setting n = number of records in tmp_humref1 = 97
    
SET i = 0; 

#Step 1
WHILE i<n DO

if i < 671 then

select zipcodes from mmsa LIMIT i,1 into zip;

elseif i > 670 and i < 1341 then

SET m = i - 670;
select zipcodes from mmsa LIMIT m,1 into zip;

elseif i > 1340 and i < 2011 then

SET m = i - 1340;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 2010 and i < 2681 then

SET m = i - 2010;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 2680 and i < 3351 then

SET m = i - 2680;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 3350 and i < 4021 then

SET m = i - 3350;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 4020 and i < 4691 then

SET m = i - 4020;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 4690 and i < 5361 then

SET m = i - 4690;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 5360 and i < 6031 then

SET m = i - 5360;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 6030 and i < 6701 then

SET m = i - 6030;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 6700 and i < 7371 then

SET m = i - 6700;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 7370 and i < 8041 then

SET m = i - 7370;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 8040 and i < 8711 then

SET m = i - 8040;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 8710 and i < 9381 then

SET m = i - 8710;
select zipcodes from mmsa LIMIT m ,1 into zip;

elseif i > 9380 and i < 10001 then

SET m = i - 9380;
select zipcodes from mmsa LIMIT m ,1 into zip;

end if;

update demo 
set zipcodes = zip 
where rown = (i + 1);

SET i = i + 1;
END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `mmsa_zip2d` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `mmsa_zip2d`()
BEGIN
DECLARE n INT DEFAULT 0;
DECLARE i INT DEFAULT 0;
DECLARE m INT DEFAULT 0;

SET m = 6253;

SELECT 
    COUNT(*)
FROM
    mmsa INTO n;  # setting n = number of records in tmp_humref1 = 97
    
SET i = 0; 

#Step 1
WHILE i<n DO

update mmsa
set zip2d_iri = concat('SEV_000000', m)
where rown = (i + 1);

SET i = i + 1;
SET m = m + 1;

END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_bpbmi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_bpbmi`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
DECLARE d int default 0;
SET n = 276008;
SET i = 0; 
SET k = 8313;
SET a = 284321;
SET b = 560329;
SET c = 836337;
SET d = 1114345;

WHILE i<n 
DO

	select rown from ocrsev.bpbmi LIMIT i,1 into m;
	if (k < 10000 and k > 999) and (c > 836336 and c < 1000000) then
		update ocrsev.brfss_smart set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.brfss_smart set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.brfss_smart set bmi =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.brfss_smart set tu_uri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.brfss_smart set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 100000 and k > 9999) and (c > 836336 and c < 1000000) then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.brfss_smart set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 1000000 and k > 99999) and (c > 836336 and c < 1000000) then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.brfss_smart set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 10000 and k > 999) and (c > 999999 and c < 10000000) then
		update ocrsev.brfss_smart set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.brfss_smart set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.brfss_smart set bmi =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.brfss_smart set tu_uri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.brfss_smart set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 100000 and k > 9999) and (c > 999999 and c < 10000000) then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.brfss_smart set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 1000000 and k > 99999) and (c > 999999 and c < 10000000) then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.brfss_smart set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	end if;
end while;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_bpbmi111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_bpbmi111`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
DECLARE d int default 0;
SET n = 276008;
SET i = 0; 
SET k = 8313;
SET a = 284321;
SET b = 560329;
SET c = 836337;
SET d = 1114345;

WHILE i<n 
DO

	select rown from ocrsev.bpbmi LIMIT i,1 into m;
	if (k < 10000 and k > 999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_uri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 100000 and k > 9999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set prev_uri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.bpbmi set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set space_uri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 1000000 and k > 99999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set prev_uri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.bpbmi set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set space_uri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 10000 and k > 999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_uri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 100000 and k > 9999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set prev_uri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.bpbmi set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set space_uri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 1000000 and k > 99999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set prev_uri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.bpbmi set coll_uri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set role_uri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set space_uri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_uri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	end if;
end while;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_bpbmi1111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_bpbmi1111`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
DECLARE d int default 0;
SET n = 276008;
SET i = 0; 
SET k = 8313;
SET a = 284321;
SET b = 560329;
SET c = 836337;
SET d = 1114345;

WHILE i<n 
DO

	select rown from ocrsev.bpbmi LIMIT i,1 into m;
	if (k < 10000 and k > 999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 100000 and k > 9999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 1000000 and k > 99999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 10000 and k > 999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 100000 and k > 9999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 1000000 and k > 99999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	end if;
end while;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_bpbmi222` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_bpbmi222`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
DECLARE d int default 0;
SET n = 276008;
SET i = 0; 
SET k = 8313;
SET a = 284321;
SET b = 560329;
SET c = 836337;
SET d = 1114345;

WHILE i<n 
DO

	select rown from ocrsev.bpbmi LIMIT i,1 into m;
	if (k < 10000 and k > 999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 100000 and k > 9999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 1000000 and k > 99999) and (c > 836336 and c < 1000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(6)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	elseif (k < 10000 and k > 999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 100000 and k > 9999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_00000", convert(k, char(5)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
    elseif (k < 1000000 and k > 99999) and (c > 999999 and c < 10000000) then
		update ocrsev.bpbmi set bpmd_iri =  (concat("SEV_0000", convert(k, char(6)))) where rown = m;
		update ocrsev.bpbmi set bp_iri =  (concat("SEV_0000", convert(a, char(6)))) where rown = m;
		update ocrsev.bpbmi set bmi_iri =  (concat("SEV_0000", convert(b, char(6)))) where rown = m;
		update ocrsev.bpbmi set tu_iri =  (concat("SEV_0000", convert(c, char(7)))) where rown = m;
		update ocrsev.bpbmi set turole_iri =  (concat("SEV_000", convert(d, char(7)))) where rown = m;
	end if;
    
SET i = i + 1;
SET k = k + 1;
SET a = a + 1;
SET b = b + 1;
SET c = c + 1;
SET d = d + 1;
SET m = NULL;
    
end while;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_brfss` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_brfss`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
SET n = 12;
SET i = 0; 
SET k = 19;
SET a = 1491;
SET b = 2801;
SET c = 4192;

WHILE i<n 
DO

	select rown from ocrsev.brfss_smart LIMIT i,1 into m;
	if (k < 99 and k > 9) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000000", convert(k, char(2)))) where zipcode = m;
        update ocrsev.brfss_smart set coll_uri =  (concat("SEV_00000000", convert(a, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_00000000", convert(b, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_00000000", convert(c, char(2)))) where zipcode = m;
    elseif (k < 999 and k > 99) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000000", convert(k, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_0000000", convert(a, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_0000000", convert(b, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_0000000", convert(c, char(2)))) where zipcode = m;
    elseif (k < 9999 and k > 999) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_000000", convert(k, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(2)))) where zipcode = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(2)))) where zipcode = m;
    end if;

	SET i = i + 1;
    SET k = k + 1;
    SET a = a + 1;
    SET b = b + 1;
    SET c = c + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_brfss1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_brfss1`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
SET n = 12;
SET i = 0; 
SET k = 19;
SET a = 1491;
SET b = 2801;
SET c = 4192;

WHILE i<n 
DO

	select rown from ocrsev.brfss_smart LIMIT i,1 into m;
	if (k < 99 and k > 9) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000000", convert(k, char(2)))) where rown = m;
        update ocrsev.brfss_smart set coll_uri =  (concat("SEV_00000000", convert(a, char(2)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_00000000", convert(b, char(2)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_00000000", convert(c, char(2)))) where rown = m;
    elseif (k < 999 and k > 99) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000000", convert(k, char(2)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_0000000", convert(a, char(2)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_0000000", convert(b, char(2)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_0000000", convert(c, char(2)))) where rown = m;
    elseif (k < 9999 and k > 999) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_000000", convert(k, char(2)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(2)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(2)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(2)))) where rown = m;
    end if;

	SET i = i + 1;
    SET k = k + 1;
    SET a = a + 1;
    SET b = b + 1;
    SET c = c + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_brfss11` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_brfss11`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
SET n = 1391;
SET i = 0; 
SET k = 19;
SET a = 1491;
SET b = 2801;
SET c = 4192;

WHILE i<n 
DO

	select rown from ocrsev.brfss_smart LIMIT i,1 into m;
	if (k < 99 and k > 9) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000000", convert(k, char(2)))) where rown = m;
    elseif (k < 999 and k > 99) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000000", convert(k, char(3)))) where rown = m;
	elseif (k < 9999 and k > 999) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(4)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(4)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(4)))) where rown = m;
    end if;

	SET i = i + 1;
    SET k = k + 1;
    SET a = a + 1;
    SET b = b + 1;
    SET c = c + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_brfss111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_brfss111`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
SET n = 1391;
SET i = 0; 
SET k = 19;
SET a = 1410;
SET b = 2801;
SET c = 4192;

WHILE i<n 
DO

	select rown from ocrsev.brfss_smart LIMIT i,1 into m;
	if (k < 99 and k > 9) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000000", convert(k, char(2)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(4)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(4)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(4)))) where rown = m;
    elseif (k < 999 and k > 99) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000000", convert(k, char(3)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(4)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(4)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(4)))) where rown = m;
    elseif (k < 9999 and k > 999) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(4)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(4)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(4)))) where rown = m;
    end if;

	SET i = i + 1;
    SET k = k + 1;
    SET a = a + 1;
    SET b = b + 1;
    SET c = c + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_brfssSmart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_brfssSmart`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
SET n = 12;
SET i = 0; 
SET k = 19;
SET a = 1491;
SET b = 2801;
SET c = 4192;

WHILE i<n 
DO

	select rown from ocrsev.brfss_smart LIMIT i,1 into m;
	if (k < 99 and k > 9) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000000", convert(k, char(2)))) where rown = m;
    elseif (k < 999 and k > 99) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000000", convert(k, char(3)))) where rown = m;
	elseif (k < 9999 and k > 999) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(4)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(4)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(4)))) where rown = m;
    end if;

	SET i = i + 1;
    SET k = k + 1;
    SET a = a + 1;
    SET b = b + 1;
    SET c = c + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_brfss_smart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_brfss_smart`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
DECLARE a int default 0;
DECLARE b int default 0;
DECLARE c int default 0;
SET n = 12;
SET i = 0; 
SET k = 19;
SET a = 1491;
SET b = 2801;
SET c = 4192;

WHILE i<n 
DO

	select rown from ocrsev.brfss_smart LIMIT i,1 into m;
	if (k < 99 and k > 9) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_00000000", convert(k, char(2)))) where rown = m;
        update ocrsev.brfss_smart set coll_uri =  (concat("SEV_00000000", convert(a, char(2)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_00000000", convert(b, char(2)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_00000000", convert(c, char(2)))) where rown = m;
    elseif (k < 999 and k > 99) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_0000000", convert(k, char(3)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_0000000", convert(a, char(3)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_0000000", convert(b, char(3)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_0000000", convert(c, char(3)))) where rown = m;
    elseif (k < 9999 and k > 999) 
    then
		update ocrsev.brfss_smart set prev_uri =  (concat("SEV_000000", convert(k, char(4)))) where rown = m;
		update ocrsev.brfss_smart set coll_uri =  (concat("SEV_000000", convert(a, char(4)))) where rown = m;
		update ocrsev.brfss_smart set role_uri =  (concat("SEV_000000", convert(b, char(4)))) where rown = m;
		update ocrsev.brfss_smart set space_uri =  (concat("SEV_000000", convert(c, char(4)))) where rown = m;
    end if;

	SET i = i + 1;
    SET k = k + 1;
    SET a = a + 1;
    SET b = b + 1;
    SET c = c + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_demo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_demo`()
BEGIN
DECLARE n INT DEFAULT 0;
DECLARE i INT DEFAULT 0;
DECLARE m INT DEFAULT 0;
SET n = 10000;
SET i = 0; 

WHILE i<n DO

select pnhid1_uri from ocrsev.demo LIMIT i,1 into m;

update ocrsev.demo set rip1_uri = m + 10001;
update ocrsev.demo set hlid2_uri = m + 20002;
update ocrsev.demo set pnhid2_uri = m + 30003;
update ocrsev.demo set rta2_uri =  m + 40004;
update ocrsev.demo set ridqap1_uri =  m + 50005;

SET i = i + 1;
END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_demo1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_demo1`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m BIGINT DEFAULT 0;
SET n = 10000;
SET i = 0; 

WHILE i<n DO

select pnhid1_uri from ocrsev.demo LIMIT i,1 into m;

update ocrsev.demo set rip1_uri = m + 10001;
update ocrsev.demo set hlid2_uri = m + 20002;
update ocrsev.demo set pnhid2_uri = m + 30003;
update ocrsev.demo set rta2_uri =  m + 40004;
update ocrsev.demo set ridqap1_uri =  m + 50005;

SET i = i + 1;
END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_demo2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_demo2`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m BIGINT DEFAULT 0;
SET n = 10000;
SET i = 0; 

WHILE i<n DO

select pnhid1_uri from ocrsev.demo LIMIT i,1 into m;

update ocrsev.demo set rip1_uri = m + 10001 where demo.pnhid1_uri = m;
update ocrsev.demo set hlid2_uri = m + 20002 where demo.pnhid1_uri = m;
update ocrsev.demo set pnhid2_uri = m + 30003 where demo.pnhid1_uri = m;
update ocrsev.demo set rta2_uri =  m + 40004 where demo.pnhid1_uri = m;
update ocrsev.demo set ridqap1_uri =  m + 50005 where demo.pnhid1_uri = m;

SET i = i + 1;
END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_geo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_geo`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
SET n = 12;
SET i = 0; 

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (m < 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat('SEV_000000000', i) where zipcode = m;
	elseif (m < 99 and m > 8) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat('SEV_00000000', i) where zip_uri = m;
	end if;

	SET i = i + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_geo1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_geo1`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
SET n = 12;
SET i = 0; 

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (i < 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat('SEV_000000000', i+1) where zipcode = m;
	elseif (i < 99 and i > 8) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat('SEV_00000000', i+1) where zip_uri = m;
	end if;

	SET i = i + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_geo111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_geo111`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
SET n = 12;
SET i = 0; 
SET k = 7;

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (i < 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat("SEV_000000000", k) where zipcode = m;
	elseif (i < 99 and i > 8) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat("SEV_00000000", k) where zip_uri = m;
	end if;

	SET i = i + 1;
    SET k = k + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_geo1111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_geo1111`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
SET n = 12;
SET i = 0; 
SET k = 7;

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (i < 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat("SEV_000000000", convert(k, char(2))) where zipcode = m;
	elseif (i < 99 and i > 8) 
    then
		update ocrsev.geo_lookup set zip_uri =  concat("SEV_00000000", convert(k, char(2))) where zip_uri = m;
	end if;

	SET i = i + 1;
    SET k = k + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_geoo1111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_geoo1111`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
SET n = 12;
SET i = 0; 
SET k = 7;

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (i < 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_000000000", convert(k, char(2)))) where zipcode = m;
	elseif (i < 99 and i > 8) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_00000000", convert(k, char(2)))) where zip_uri = m;
	end if;

	SET i = i + 1;
    SET k = k + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_geooo1111` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_geooo1111`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
SET n = 12;
SET i = 0; 
SET k = 7;

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (i < 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_000000000", convert(k, char(2)))) where zipcode = m;
	elseif (i < 99 and i > 8) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_00000000", convert(k, char(2)))) where zipcode = m;
	end if;

	SET i = i + 1;
    SET k = k + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_lookgeo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_lookgeo`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
SET n = 12;
SET i = 0; 
SET k = 7;

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (k < 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_000000000", convert(k, char(2)))) where zipcode = m;
	elseif (k < 99 and k > 8) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_00000000", convert(k, char(2)))) where zipcode = m;
	end if;

	SET i = i + 1;
    SET k = k + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_lookgeo1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_lookgeo1`()
BEGIN
DECLARE n bigint DEFAULT 0;
DECLARE i bigint DEFAULT 0;
DECLARE m bigint default 0;
DECLARE k int default 0;
SET n = 12;
SET i = 0; 
SET k = 7;

WHILE i<n 
DO

	select zipcode from ocrsev.geo_lookup LIMIT i,1 into m;
	if (k < 10) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_000000000", convert(k, char(2)))) where zipcode = m;
	elseif (k < 99 and k > 9) 
    then
		update ocrsev.geo_lookup set zip_uri =  (concat("SEV_00000000", convert(k, char(2)))) where zipcode = m;
	end if;

	SET i = i + 1;
    SET k = k + 1;
	SET m = NULL;

END WHILE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-27  1:02:02
